```python
# This notebook is aimed at forecating the price of local rice whole sale price
```


```python
# Starting by importing required libraries
import warnings
import itertools
import numpy as np
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
plt.style.use('fivethirtyeight')
import pandas as pd
%matplotlib inline
import seaborn as sns 
import statsmodels.api as sm
```


```python
# Then loading the document and reading as a data frame
# the document has already been filtered in excel to get only rows containing data on local rice wholesale
df = pd.read_csv(r'C:\Users\User\Desktop\Local Rice Wholesale.csv', parse_dates=['date'])
```


```python
# Checking the overview of the loaded data set
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>cmname</th>
      <th>unit</th>
      <th>category</th>
      <th>price</th>
      <th>currency</th>
      <th>country</th>
      <th>admname</th>
      <th>adm1id</th>
      <th>mktname</th>
      <th>...</th>
      <th>umid</th>
      <th>catid</th>
      <th>sn</th>
      <th>default</th>
      <th>year</th>
      <th>label</th>
      <th>cmnameshort</th>
      <th>scaling</th>
      <th>interpolated</th>
      <th>x</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2015-01-15</td>
      <td>Rice (local) - Wholesale</td>
      <td>1/100 100 KG</td>
      <td>cereals and tubers</td>
      <td>135.75</td>
      <td>NGN</td>
      <td>Nigeria</td>
      <td>Kebbi</td>
      <td>2227.0</td>
      <td>Gwandu</td>
      <td>...</td>
      <td>9.0</td>
      <td>1</td>
      <td>1974_71_14_9</td>
      <td>NaN</td>
      <td>2015.0</td>
      <td>Rice (local) - Wholesale (1/100 100 KG)</td>
      <td>Rice loc. Whs.</td>
      <td>0.01</td>
      <td>0</td>
      <td>1.421280e+09</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-02-15</td>
      <td>Rice (local) - Wholesale</td>
      <td>1/100 100 KG</td>
      <td>cereals and tubers</td>
      <td>140.00</td>
      <td>NGN</td>
      <td>Nigeria</td>
      <td>Jigawa</td>
      <td>2223.0</td>
      <td>Gujungu</td>
      <td>...</td>
      <td>9.0</td>
      <td>1</td>
      <td>1973_71_14_9</td>
      <td>NaN</td>
      <td>2015.0</td>
      <td>Rice (local) - Wholesale (1/100 100 KG)</td>
      <td>Rice loc. Whs.</td>
      <td>0.01</td>
      <td>0</td>
      <td>1.423958e+09</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015-03-15</td>
      <td>Rice (local) - Wholesale</td>
      <td>1/100 100 KG</td>
      <td>cereals and tubers</td>
      <td>140.00</td>
      <td>NGN</td>
      <td>Nigeria</td>
      <td>Jigawa</td>
      <td>2223.0</td>
      <td>Gujungu</td>
      <td>...</td>
      <td>9.0</td>
      <td>1</td>
      <td>1973_71_14_9</td>
      <td>NaN</td>
      <td>2015.0</td>
      <td>Rice (local) - Wholesale (1/100 100 KG)</td>
      <td>Rice loc. Whs.</td>
      <td>0.01</td>
      <td>0</td>
      <td>1.426378e+09</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015-04-15</td>
      <td>Rice (local) - Wholesale</td>
      <td>1/100 100 KG</td>
      <td>cereals and tubers</td>
      <td>145.75</td>
      <td>NGN</td>
      <td>Nigeria</td>
      <td>Kebbi</td>
      <td>2227.0</td>
      <td>Gwandu</td>
      <td>...</td>
      <td>9.0</td>
      <td>1</td>
      <td>1974_71_14_9</td>
      <td>NaN</td>
      <td>2015.0</td>
      <td>Rice (local) - Wholesale (1/100 100 KG)</td>
      <td>Rice loc. Whs.</td>
      <td>0.01</td>
      <td>0</td>
      <td>1.429056e+09</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015-05-15</td>
      <td>Rice (local) - Wholesale</td>
      <td>1/100 100 KG</td>
      <td>cereals and tubers</td>
      <td>146.30</td>
      <td>NGN</td>
      <td>Nigeria</td>
      <td>Jigawa</td>
      <td>2223.0</td>
      <td>Gujungu</td>
      <td>...</td>
      <td>9.0</td>
      <td>1</td>
      <td>1973_71_14_9</td>
      <td>NaN</td>
      <td>2015.0</td>
      <td>Rice (local) - Wholesale (1/100 100 KG)</td>
      <td>Rice loc. Whs.</td>
      <td>0.01</td>
      <td>0</td>
      <td>1.431648e+09</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>




```python
# checking for data types
df.dtypes
```




    date            datetime64[ns]
    cmname                  object
    unit                    object
    category                object
    price                  float64
    currency                object
    country                 object
    admname                 object
    adm1id                 float64
    mktname                 object
    mktid                  float64
    cmid                     int64
    ptid                   float64
    umid                   float64
    catid                    int64
    sn                      object
    default                float64
    year                   float64
    label                   object
    cmnameshort             object
    scaling                float64
    interpolated             int64
    x                      float64
    dtype: object




```python
# checking for missing data
df.isnull().sum()
```




    date             0
    cmname           0
    unit             0
    category         0
    price            0
    currency         2
    country          2
    admname          2
    adm1id           2
    mktname          2
    mktid            2
    cmid             0
    ptid             2
    umid             2
    catid            0
    sn               2
    default         72
    year             2
    label            0
    cmnameshort      0
    scaling          0
    interpolated     0
    x                2
    dtype: int64




```python
# getting an overview of the state column
df.admname.value_counts()
```




    Jigawa     13
    Borno      11
    Gombe       9
    Kaduna      8
    Kebbi       6
    Kano        6
    Katsina     5
    Yobe        5
    Zamfara     4
    Oyo         3
    Name: admname, dtype: int64




```python
# filling the missing states name with Jigawa, the highest occuring location
df['admname'].fillna('Jigawa', inplace=True)
```


```python
# confirming if all of the missing values are filled
df['admname'].isnull().value_counts()
```




    False    72
    Name: admname, dtype: int64




```python
#renaming the column to suit the task
df = df.rename(columns={'admname': 'State'})
```


```python
# Since all we need is the date, state and price of the commodity
# we would extract this data into a new data frame
df2 = df[['date', 'State', 'price']]
```


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>State</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2015-01-15</td>
      <td>Kebbi</td>
      <td>135.75</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-02-15</td>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015-03-15</td>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015-04-15</td>
      <td>Kebbi</td>
      <td>145.75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015-05-15</td>
      <td>Jigawa</td>
      <td>146.30</td>
    </tr>
  </tbody>
</table>
</div>




```python
#renaming the column to suit the task
df2 = df2.rename(columns={'date': 'Date'})
df2 = df2.rename(columns={'price': 'Price/Kg'})

```


```python
by_state = df2.groupby (['Date','State'])[['Price/Kg']].median().reset_index()
```


```python
by_state
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>State</th>
      <th>Price/Kg</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2015-01-15</td>
      <td>Kebbi</td>
      <td>135.75</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-02-15</td>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015-03-15</td>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015-04-15</td>
      <td>Kebbi</td>
      <td>145.75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015-05-15</td>
      <td>Jigawa</td>
      <td>146.30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>2020-08-15</td>
      <td>Borno</td>
      <td>409.08</td>
    </tr>
    <tr>
      <th>68</th>
      <td>2020-09-15</td>
      <td>Borno</td>
      <td>404.35</td>
    </tr>
    <tr>
      <th>69</th>
      <td>2020-10-15</td>
      <td>Jigawa</td>
      <td>345.00</td>
    </tr>
    <tr>
      <th>70</th>
      <td>2020-11-15</td>
      <td>Jigawa</td>
      <td>336.00</td>
    </tr>
    <tr>
      <th>71</th>
      <td>2020-12-15</td>
      <td>Gombe</td>
      <td>345.00</td>
    </tr>
  </tbody>
</table>
<p>72 rows × 3 columns</p>
</div>




```python
by_state=by_state.set_index('Date')
```


```python

```


```python
y = by_state
y
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>State</th>
      <th>Price/Kg</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-01-15</th>
      <td>Kebbi</td>
      <td>135.75</td>
    </tr>
    <tr>
      <th>2015-02-15</th>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2015-03-15</th>
      <td>Jigawa</td>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2015-04-15</th>
      <td>Kebbi</td>
      <td>145.75</td>
    </tr>
    <tr>
      <th>2015-05-15</th>
      <td>Jigawa</td>
      <td>146.30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-08-15</th>
      <td>Borno</td>
      <td>409.08</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>Borno</td>
      <td>404.35</td>
    </tr>
    <tr>
      <th>2020-10-15</th>
      <td>Jigawa</td>
      <td>345.00</td>
    </tr>
    <tr>
      <th>2020-11-15</th>
      <td>Jigawa</td>
      <td>336.00</td>
    </tr>
    <tr>
      <th>2020-12-15</th>
      <td>Gombe</td>
      <td>345.00</td>
    </tr>
  </tbody>
</table>
<p>72 rows × 2 columns</p>
</div>




```python

```


```python
y.drop('State', inplace = True, axis = 1)

```


```python
y['2015':]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price/Kg</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-01-15</th>
      <td>135.75</td>
    </tr>
    <tr>
      <th>2015-02-15</th>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2015-03-15</th>
      <td>140.00</td>
    </tr>
    <tr>
      <th>2015-04-15</th>
      <td>145.75</td>
    </tr>
    <tr>
      <th>2015-05-15</th>
      <td>146.30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-08-15</th>
      <td>409.08</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>404.35</td>
    </tr>
    <tr>
      <th>2020-10-15</th>
      <td>345.00</td>
    </tr>
    <tr>
      <th>2020-11-15</th>
      <td>336.00</td>
    </tr>
    <tr>
      <th>2020-12-15</th>
      <td>345.00</td>
    </tr>
  </tbody>
</table>
<p>72 rows × 1 columns</p>
</div>




```python
# Plotting our data to visualize the price change over the years
y.plot(figsize=(15,6))

```




    <matplotlib.axes._subplots.AxesSubplot at 0x144e9ce8a48>




![png](output_21_1.png)



```python
# the plot above shows that there is rarely seasonality pattern, especially 



```


```python
# converting data to log form for simplicity
y_log = np.log(y)
plt.plot(y_log)
```




    [<matplotlib.lines.Line2D at 0x144e9c7e988>]




![png](output_23_1.png)



```python
# performing differncing to limit seasonality
y_log_diff = y_log - y_log.shift()
plt.plot(y_log_diff)
```




    [<matplotlib.lines.Line2D at 0x144ea9032c8>]




![png](output_24_1.png)



```python
y_log_diff.dropna(inplace=True)
```


```python
# creating the model
model = ARIMA(y_log, order=(2, 1, 2))  
results_ARIMA = model.fit(disp=-1)  
plt.plot(y_log_diff)
plt.plot(results_ARIMA.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-y_log_diff)**2))
```

    C:\Users\User\anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:218: ValueWarning: A date index has been provided, but it has no associated frequency information and so will be ignored when e.g. forecasting.
      ' ignored when e.g. forecasting.', ValueWarning)
    C:\Users\User\anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:218: ValueWarning: A date index has been provided, but it has no associated frequency information and so will be ignored when e.g. forecasting.
      ' ignored when e.g. forecasting.', ValueWarning)
    C:\Users\User\anaconda3\lib\site-packages\statsmodels\base\model.py:548: HessianInversionWarning: Inverting hessian failed, no bse or cov_params available
      'available', HessianInversionWarning)
    


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    <ipython-input-33-57318be6c061> in <module>
          3 plt.plot(y_log_diff)
          4 plt.plot(results_ARIMA.fittedvalues, color='red')
    ----> 5 plt.title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-y_log_diff)**2))
    

    pandas\_libs\tslibs\timestamps.pyx in pandas._libs.tslibs.timestamps.Timestamp.__radd__()
    

    pandas\_libs\tslibs\c_timestamp.pyx in pandas._libs.tslibs.c_timestamp._Timestamp.__add__()
    

    TypeError: Addition/subtraction of integers and integer-arrays with Timestamp is no longer supported.  Instead of adding/subtracting `n`, use `n * obj.freq`



![png](output_26_2.png)



```python
#taking it back to original scale
predictions_ARIMA_diff = pd.Series(results_ARIMA.fittedvalues, copy=True)
print (predictions_ARIMA_diff.head())
```

    Date
    2015-02-15    0.013324
    2015-03-15    0.016145
    2015-04-15    0.012554
    2015-05-15    0.016020
    2015-06-15    0.012509
    dtype: float64
    


```python
predictions_ARIMA_diff_cumsum = predictions_ARIMA_diff.cumsum()
print (predictions_ARIMA_diff_cumsum.head())
```

    Date
    2015-02-15    0.013324
    2015-03-15    0.029469
    2015-04-15    0.042023
    2015-05-15    0.058043
    2015-06-15    0.070552
    dtype: float64
    


```python
predictions_ARIMA_log = pd.Series(y_log['Price/Kg'], index=y_log.index)
predictions_ARIMA_log = predictions_ARIMA_log.add(predictions_ARIMA_diff_cumsum,fill_value=0)
predictions_ARIMA_log.head()
```




    Date
    2015-01-15    4.910815
    2015-02-15    4.954967
    2015-03-15    4.971111
    2015-04-15    5.023916
    2015-05-15    5.043702
    dtype: float64




```python
# Taking exponents and making predictions
predictions_ARIMA = np.exp(predictions_ARIMA_log)
plt.plot(y)
plt.plot(predictions_ARIMA)
plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_ARIMA-y)**2)/len(y)))
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    <ipython-input-48-e162605ef582> in <module>
          2 plt.plot(y)
          3 plt.plot(predictions_ARIMA)
    ----> 4 plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_ARIMA-y)**2)/len(y)))
    

    pandas\_libs\tslibs\timestamps.pyx in pandas._libs.tslibs.timestamps.Timestamp.__radd__()
    

    pandas\_libs\tslibs\c_timestamp.pyx in pandas._libs.tslibs.c_timestamp._Timestamp.__add__()
    

    TypeError: Addition/subtraction of integers and integer-arrays with Timestamp is no longer supported.  Instead of adding/subtracting `n`, use `n * obj.freq`



![png](output_30_1.png)

